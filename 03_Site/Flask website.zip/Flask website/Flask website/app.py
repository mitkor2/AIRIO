from flask import Flask, render_template, request
import mysql.connector
import requests
import json

# timestamp, temperature, humidity, pressure, ozone, carbonMonoxide, sulfurDioxide, nitrogenDioxide, pm1_0, pm2_5,
# pm4_0, pm10, airq, vbatt, cbatt, fixQuality, latitude, longitude, altitude
from mysql.connector import IntegrityError

sql = "INSERT INTO data (timestamp, temperature, humidity, pressure, ozone, carbonMonoxide, sulfurDioxide, " \
      "nitrogenDioxide, pm1_0, pm2_5, pm4_0, pm10, airq, vbatt, cbatt, fixQuality, latitude, longitude, " \
      "altitude) VALUES (%s, %s ,%s ," \
      "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) "

app = Flask(__name__)

# тази част е за моята си локал датабаза
# # ___________________________________
db = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="",  # db password
    database="measurements"
)
cur = db.cursor()
# # ___________________________________


def request_data():
    # request = requests.get('www.tvoqAPI.bg')
    # content = request.text
    # # кода отгоре за АПИ-то

    # # with open трябва да се мнахне иначе
    with open("json", "r") as file:
        content = file.read()

    data = json.loads(content)

    return data['data']


def get_data():
    cur.execute("SELECT * FROM data")
    return cur.fetchall()


# ако го има вече не го добавя
def add_data():
    data_dict = request_data()

    timestamp = data_dict['timestamp']
    temperature = data_dict['temperature']
    humidity = data_dict['humidity']
    pressure = data_dict['pressure']
    ozone = data_dict['ozone']
    carbonMonoxide = data_dict['carbonMonoxide']
    sulfurDioxide = data_dict['sulfurDioxide']
    nitrogenDioxide = data_dict['nitrogenDioxide']
    pm1_0 = data_dict['pm1_0']
    pm2_5 = data_dict['pm2_5']
    pm4_0 = data_dict['pm4_0']
    pm10 = data_dict['pm10']
    airq = data_dict['airq']
    vbatt = data_dict['vbatt']
    cbatt = data_dict['cbatt']
    fixQuality = data_dict['fixQuality']
    latitude = data_dict['latitude']
    longitude = data_dict['longitude']
    altitude = data_dict['altitude']
    try:
        cur.execute(sql,
                    tuple("{} {} {} {} {} {} {} {} {} {} {} {} {} {} {} {} {} {} {}"
                          .format(timestamp, temperature, humidity, pressure, ozone, carbonMonoxide, sulfurDioxide,
                                  nitrogenDioxide, pm1_0, pm2_5, pm4_0, pm10, airq, vbatt, cbatt, fixQuality, latitude,
                                  longitude, altitude)
                          .split()))
        db.commit()
    except IntegrityError:
        print("already in")


@app.route('/', methods=['POST', 'GET'])
def index():
    if request.method == "POST":
        add_data()

    return render_template('index.html', rows=get_data())


if __name__ == "__main__":
    app.run(debug=True)
